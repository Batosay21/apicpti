package br.com.empresa.entity;

public class Produto {

}
