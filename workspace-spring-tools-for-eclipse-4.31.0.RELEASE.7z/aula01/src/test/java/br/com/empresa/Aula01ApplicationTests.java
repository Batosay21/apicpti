package br.com.empresa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
